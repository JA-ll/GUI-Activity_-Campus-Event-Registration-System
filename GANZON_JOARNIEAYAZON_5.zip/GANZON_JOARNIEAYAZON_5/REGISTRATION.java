import javax.swing.*;
import java.awt.*;

public class REGISTRATION {
    public static void main( String [] args ){
        JFrame frame = new JFrame("Report");
        frame.setSize(500, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));


        JLabel lblName = new JLabel("Participant Name: ");
        JTextField txtName = new JTextField(20);
        JLabel lblAge = new JLabel("Age: ");
        JTextField txtAge = new JTextField(20);

        JLabel lblDepartment = new JLabel("College/Department: ");
        String [] Department = {
            "Select Your Department", "BSIT", "BFPT", "BTLED"
        };
        JComboBox<String> cmbDepartment = new JComboBox(Department);

        JLabel lblEvent = new JLabel("Event Category: ");
        String [] Event = {
            "Select Event", "Programming Competition", "Web Design Challenge", "Cybersecurity Seminar", 
            "AI and Emerging Technologies", "IT Quiz Bowl"
        };
        JComboBox<String> cmbEvent = new JComboBox(Event); 

        JLabel lblParticipant = new JLabel("Attendance Type: ");
        JRadioButton a = new JRadioButton("Student Participant");
        JRadioButton b = new JRadioButton("Student Audience");
        JRadioButton c = new JRadioButton("Faculty/Staff");

        ButtonGroup btgParticipant = new ButtonGroup();
        btgParticipant.add(a);
        btgParticipant.add(b);
        btgParticipant.add(c);

        JLabel lblWorkShop = new JLabel("WorkShops: ");
        JCheckBox C1 = new JCheckBox("Java Programming");
        JCheckBox C2 = new JCheckBox("Web Development");
        JCheckBox C3 = new JCheckBox("Cybersecurity");
        JCheckBox C4 = new JCheckBox("Artificial Intelligence");
        JCheckBox C5 = new JCheckBox("Database Management");

        JLabel lblRequest = new JLabel("Special Request: ");
        JTextArea txtRequest = new JTextArea(1, 40);

        JButton btnRegister = new JButton("Register");
        JButton btnClear = new JButton("Clear");

        txtRequest.setLineWrap(true);
        txtRequest.setWrapStyleWord(true);


        frame.add(lblName);
        frame.add(txtName);
        frame.add(lblAge);
        frame.add(txtAge);

        frame.add(lblDepartment);
        frame.add(cmbDepartment);

        frame.add(lblEvent);
        frame.add(cmbEvent);

        frame.add(lblParticipant);
        frame.add(a);
        frame.add(b);
        frame.add(c);

        frame.add(lblWorkShop);
        frame.add(C1);
        frame.add(C2);
        frame.add(C3);
        frame.add(C4);
        frame.add(C5);

        frame.add(lblRequest);
        frame.add(txtRequest);
        

        frame.add(btnRegister);
        frame.add(btnClear);

        btnRegister.addActionListener(e ->{
            
            String Nametxt = txtName.getText().trim();
            String Agetxt = txtAge.getText().trim();
            String Departmenttxt = cmbDepartment.getSelectedItem().toString();
            String Eventtxt = cmbEvent.getSelectedItem().toString();
            String Participanttxt = btgParticipant.toString();
            if (a.isSelected()){
                Participanttxt = "Student Participant";
            }else if (b.isSelected()){
                Participanttxt = "Student Audience";
            }else if (c.isSelected()){
                Participanttxt = "Faculty/Staff";
            }

            String WorkShopstxt = "";
            if(C1.isSelected()){
                WorkShopstxt += "\nJava Programming";
            }
            if(C2.isSelected()){
                WorkShopstxt += "\nWeb Development";
            }
            if(C3.isSelected()){
                WorkShopstxt += "\nCybersecurity";
            }
            if(C4.isSelected()){
                WorkShopstxt += "\nArtificial Intelligence";
            }
            if(C5.isSelected()){
                WorkShopstxt += "\nDatabase Management";
            }
       
            
            if (Nametxt.isEmpty() || Agetxt.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "All fields are required!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (!Nametxt.matches("[a-zA-Z \\.]+")) {
                JOptionPane.showMessageDialog(frame, "Name can only contain letters!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String Requesttxt = txtRequest.getText().trim();

            try{
                int AgeInt = Integer.parseInt(Agetxt);

                if (AgeInt < 1 || AgeInt > 120) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid age between 1 and 130!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
                }

                String output = "REGISTRATION\n\n" + "Name: " + Nametxt + "\nAge: " + AgeInt + "\nDepartment: " + Departmenttxt +
                "\nEvent: " + Eventtxt + "\nParticipant: " + Participanttxt + "\nWorkshops: " + WorkShopstxt + "\n\nSpecial Request: " + Requesttxt;

                JOptionPane.showMessageDialog(frame, output);
            }catch (NumberFormatException ex){
                    JOptionPane.showMessageDialog(frame, "Required Input is Missing or Invalid!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
        });

        btnClear.addActionListener(e ->{
        txtName.setText("");

        txtAge.setText("");


        cmbDepartment.setSelectedIndex(0);

        cmbEvent.setSelectedIndex(0);

        btgParticipant.clearSelection();
       


        C1.setSelected(false);
        C2.setSelected(false);
        C3.setSelected(false);
        C4.setSelected(false);
        C5.setSelected(false);

        txtRequest.setText("");
        
        });

        frame.setVisible(true);
    }
}